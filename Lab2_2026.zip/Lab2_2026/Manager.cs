﻿using System;

class Manager : Employee
{
    private int TeamSize;

    public Manager(string name, int age, string employeeId, string department, int teamSize) : base(name, age, employeeId, department)
    {
        TeamSize = teamSize;
    }

    public int GetTeamSize()
    {
        return TeamSize;
    }

    public void SetTeamSize(int teamSize)
    {
        TeamSize = teamSize;
    }

    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine("Team Size: " + TeamSize);
    }
}