﻿using System;

class Employee : Person
{
    protected string EmployeeId;
    protected string Department;

    public Employee(string name, int age, string employeeId, string department) : base(name, age)
    {
        EmployeeId = employeeId;
        Department = department;
    }

    public Employee(string employeeId, string department) : base("Default Name", 25)
    {
        EmployeeId = employeeId;
        Department = department;
    }

    public string GetEmployeeId()
    {
        return EmployeeId;
    }

    public void SetEmployeeId(string employeeId)
    {
        EmployeeId = employeeId;
    }

    public string GetDepartment()
    {
        return Department;
    }

    public void SetDepartment(string department)
    {
        Department = department;
    }

    public void DisplayEmployeeDetails()
    {
        DisplayDetails();
    }

    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine("Employee ID: " + EmployeeId);
        Console.WriteLine("Department: " + Department);
    }
}