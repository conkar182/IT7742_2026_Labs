﻿using System;

class Person
{
    private string Name;
    private int Age;

    public Person(string name, int age)
    {
        Name = name;
        Age = age;
    }

    public Person(string name)
    {
        Name = name;
        Age = 18;
    }

    public Person()
    {
        Name = "Unknown";
        Age = 0;
    }

    public string GetName()
    {
        return Name;
    }

    public void SetName(string name)
    {
        Name = name;
    }

    public int GetAge()
    {
        return Age;
    }

    public void SetAge(int age)
    {
        Age = age;
    }

    public virtual void DisplayDetails()
    {
        Console.WriteLine("Name: " + Name);
        Console.WriteLine("Age: " + Age);
    }
}