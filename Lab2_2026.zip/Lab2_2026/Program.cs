﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Inheritance and Constructors");
        Console.WriteLine();

        Employee emp1 = new Employee("Amit", 30, "E101", "IT");
        emp1.DisplayEmployeeDetails();

        Console.WriteLine();


        Console.WriteLine("Overloaded Constructors");
        Console.WriteLine();

        Person person1 = new Person("Onkar", 22);
        Person person2 = new Person("Karan");

        Console.WriteLine("Person made with name and age:");
        person1.DisplayDetails();

        Console.WriteLine();

        Console.WriteLine("Person made with only name:");
        person2.DisplayDetails();

        Console.WriteLine();

        Employee emp2 = new Employee("E202", "Accounts");

        Console.WriteLine("Employee made with only employee id and department:");
        emp2.DisplayDetails();

        Console.WriteLine();


        Console.WriteLine("Access Modifiers and getter-setter methods");
        Console.WriteLine();

        Employee emp3 = new Employee("Karan", 28, "E303", "Sales");

        emp3.SetName("Karan Singh");
        emp3.SetAge(29);
        emp3.SetEmployeeId("E304");
        emp3.SetDepartment("Marketing");

        Console.WriteLine("Name: " + emp3.GetName());
        Console.WriteLine("Age: " + emp3.GetAge());
        Console.WriteLine("Employee ID: " + emp3.GetEmployeeId());
        Console.WriteLine("Department: " + emp3.GetDepartment());

        Console.WriteLine();


        Console.WriteLine("Method overriding");
        Console.WriteLine();

        Employee emp4 = new Employee("Onkar", 21, "E405", "HR");
        emp4.DisplayDetails();

        Console.WriteLine();


        Console.WriteLine("Inheritance Hierarchy");
        Console.WriteLine();

        Person p1 = new Person("Normal Person", 25);
        Employee e1 = new Employee("Employee Person", 35, "E501", "Finance");
        Manager m1 = new Manager("Manager Person", 42, "M601", "Operations", 8);

        Console.WriteLine("Person details:");
        p1.DisplayDetails();

        Console.WriteLine();

        Console.WriteLine("Employee details:");
        e1.DisplayDetails();

        Console.WriteLine();

        Console.WriteLine("Manager details:");
        m1.DisplayDetails();

        Console.WriteLine();


        Console.WriteLine("Library system");
        Console.WriteLine();

        Book book1 = new Book("Ikigai", "Test Author", 2021, "999-4141414141", "Programming");
        Magazine magazine1 = new Magazine("Cars", "AutoWorld", 2024, 15, "Monthly");

        Console.WriteLine("Book details:");
        book1.DisplayDetails();

        Console.WriteLine();

        Console.WriteLine("Magazine details:");
        magazine1.DisplayDetails();

        Console.WriteLine();


        Console.WriteLine("Reflection");
        Console.WriteLine();

        Console.WriteLine("Most challenging was method overriding because the parent class and child class both have a method with the same name.");
        Console.WriteLine("OOP principles can help in real software because code gets more organised and easier to reuse.");
        Console.WriteLine("Inheritance and constructors can also be used in systems like banking, school records, hospital records, and online shopping.");

        Console.ReadLine();
    }
}