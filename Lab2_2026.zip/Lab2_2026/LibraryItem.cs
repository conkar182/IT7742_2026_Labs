﻿using System;

class LibraryItem
{
    private string Title;
    private string Author;
    private int PublicationYear;

    public LibraryItem(string title, string author, int publicationYear)
    {
        Title = title;
        Author = author;
        PublicationYear = publicationYear;
    }

    public string GetTitle()
    {
        return Title;
    }

    public void SetTitle(string title)
    {
        Title = title;
    }

    public string GetAuthor()
    {
        return Author;
    }

    public void SetAuthor(string author)
    {
        Author = author;
    }

    public int GetPublicationYear()
    {
        return PublicationYear;
    }

    public void SetPublicationYear(int publicationYear)
    {
        PublicationYear = publicationYear;
    }

    public virtual void DisplayDetails()
    {
        Console.WriteLine("Title: " + Title);
        Console.WriteLine("Author: " + Author);
        Console.WriteLine("Publication Year: " + PublicationYear);
    }
}