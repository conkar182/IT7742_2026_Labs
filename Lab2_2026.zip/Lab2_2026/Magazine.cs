﻿using System;

class Magazine : LibraryItem
{
    private int IssueNumber;
    private string Frequency;

    public Magazine(string title, string author, int publicationYear, int issueNumber, string frequency) : base(title, author, publicationYear)
    {
        IssueNumber = issueNumber;
        Frequency = frequency;
    }

    public int GetIssueNumber()
    {
        return IssueNumber;
    }

    public void SetIssueNumber(int issueNumber)
    {
        IssueNumber = issueNumber;
    }

    public string GetFrequency()
    {
        return Frequency;
    }

    public void SetFrequency(string frequency)
    {
        Frequency = frequency;
    }

    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine("Issue Number: " + IssueNumber);
        Console.WriteLine("Frequency: " + Frequency);
    }
}