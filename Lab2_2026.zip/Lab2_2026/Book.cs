﻿using System;

class Book : LibraryItem
{
    private string ISBN;
    private string Genre;

    public Book(string title, string author, int publicationYear, string isbn, string genre) : base(title, author, publicationYear)
    {
        ISBN = isbn;
        Genre = genre;
    }

    public string GetISBN()
    {
        return ISBN;
    }

    public void SetISBN(string isbn)
    {
        ISBN = isbn;
    }

    public string GetGenre()
    {
        return Genre;
    }

    public void SetGenre(string genre)
    {
        Genre = genre;
    }

    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine("ISBN: " + ISBN);
        Console.WriteLine("Genre: " + Genre);
    }
}