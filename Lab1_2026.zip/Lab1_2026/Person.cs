﻿class Person
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public int Age { get; set; }

    public Person()
    {
        FirstName = "Onkar";
        LastName = "Singh";
        Age = 24;
    }
}