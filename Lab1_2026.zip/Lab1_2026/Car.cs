﻿using System;

class Car
{
    public string Make { get; set; }
    public string Model { get; set; }
    public int Year { get; set; }

    public Car()
    {
    }

    public Car(string make, string model, int year)
    {
        Make = make;
        Model = model;
        Year = year;
    }

    public void DisplayInfo()
    {
        Console.WriteLine("The car is a " + Year + " " + Make + " " + Model + ".");
    }

    public void StartEngine()
    {
        Console.WriteLine("Engine started.");
    }
}