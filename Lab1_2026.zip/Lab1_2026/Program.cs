﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Task1 1");

        Car car1 = new Car();
        car1.Make = "Mercedes AMG";
        car1.Model = "A Class";
        car1.Year = 2020;

        car1.DisplayInfo();

        Console.WriteLine();


        Console.WriteLine("Task 2");

        Car car2 = new Car("Ford", "Mustang", 2022);
        car2.DisplayInfo();
        car2.StartEngine();

        Console.WriteLine();


        Console.WriteLine("Task 3");

        Book book1 = new Book();
        book1.Title = "Ikigai";
        book1.Author = "Test Author";
        book1.Pages = 333;

        book1.Read();

        Console.WriteLine();


        Console.WriteLine("Task 4");

        Person person1 = new Person();

        Console.WriteLine("First Name: " + person1.FirstName);
        Console.WriteLine("Last Name: " + person1.LastName);
        Console.WriteLine("Age: " + person1.Age);

        Console.WriteLine();


        Console.WriteLine("Task 5");

        Calculator calc = new Calculator();

        Console.WriteLine("Adding two numbers: " + calc.Add(5, 10));
        Console.WriteLine("Adding three numbers: " + calc.Add(5, 10, 15));
        Console.WriteLine("Adding four numbers: " + calc.Add(5, 10, 15, 20));

        Console.WriteLine();


        Console.WriteLine("Task 6");

        Counter counter1 = new Counter();
        Counter counter2 = new Counter();

        counter1.Increment();
        counter1.Increment();
        counter2.Increment();

        Console.WriteLine("Current count is: " + Counter.GetCount());

        Console.ReadLine();
    }
}