﻿class Counter
{
    public static int Count = 0;

    public void Increment()
    {
        Count++;
    }

    public static int GetCount()
    {
        return Count;
    }
}