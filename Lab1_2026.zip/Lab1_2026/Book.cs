﻿using System;

class Book
{
    public string Title { get; set; }
    public string Author { get; set; }
    public int Pages { get; set; }

    public void Read()
    {
        Console.WriteLine("Reading '" + Title + "' by " + Author + ".");
    }
}